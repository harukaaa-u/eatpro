package eatpro.model;

import java.time.LocalDate;

public class UserGoals {
	public enum GoalType {
		WEIGHTLOSS, GAINWEIGHT, MAINTAINHEALTH
	}
	
	public enum Status {
		ACTIVE, ACHIEVED, FAILED, ONHOLD
	}
	
    protected int goalId;
    protected String userName;
    protected GoalType goalType;
    protected LocalDate targetDate;
    protected double targetValue;
    protected Status status;
    protected LocalDate creationDate;
    protected LocalDate lastUpdated;
    
    
	public UserGoals(String userName, GoalType goalType, LocalDate targetDate, double targetValue, Status status,
			LocalDate creationDate, LocalDate lastUpdated) {
		this.userName = userName;
		this.goalType = goalType;
		this.targetDate = targetDate;
		this.targetValue = targetValue;
		this.status = status;
		this.creationDate = creationDate;
		this.lastUpdated = lastUpdated;
	}
	
	public UserGoals(int goalId) {
		this.goalId = goalId;
	}

	public UserGoals(int goalId, String userName, GoalType goalType, LocalDate targetDate, double targetValue,
			Status status, LocalDate creationDate, LocalDate lastUpdated) {
		this.goalId = goalId;
		this.userName = userName;
		this.goalType = goalType;
		this.targetDate = targetDate;
		this.targetValue = targetValue;
		this.status = status;
		this.creationDate = creationDate;
		this.lastUpdated = lastUpdated;
	}
	
	public int getGoalId() {
		return goalId;
	}
	public void setGoalId(int goalId) {
		this.goalId = goalId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public GoalType getGoalType() {
		return goalType;
	}
	public void setGoalType(GoalType goalType) {
		this.goalType = goalType;
	}
	public LocalDate getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(LocalDate targetDate) {
		this.targetDate = targetDate;
	}
	public double getTargetValue() {
		return targetValue;
	}
	public void setTargetValue(double targetValue) {
		this.targetValue = targetValue;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public LocalDate getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}
	public LocalDate getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(LocalDate lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
    
}
